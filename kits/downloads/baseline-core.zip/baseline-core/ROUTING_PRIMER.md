# Why folders, not a vector database

A one-page version of the routing paper. It explains the idea behind the briefing file, and why your agent should be told where to look instead of left to search.

## The idea
A working folder is not a pile of similar documents. It holds notes, dated logs, superseded drafts, scripts and exports. A search that returns "text that sounds like the question" cannot tell which of those is true. Position can: a short chain of instruction files says what to read, in what order, and what to ignore.

## The boot set
Every session starts by reading three small files. That is the whole cold start.

| File | Job |
| --- | --- |
| a one-line pointer | Some tools only auto-load one filename. It points at the next file and carries no rules |
| the rules file | What the agent may and may not do, and where to look first |
| your briefing (`me.md`) | Who you are, how you work, what it must never do |

Keep the three under about 1,500 tokens. Anything the agent must read first is a cost on every session.

## The lookup order
1. The **catalog** (`index.md`): one row per page, with a link, a one-line summary, a status and a date. The catalog is the retriever.
2. The **router** in the folder: a `CONTEXT.md` (what is here, what is authoritative, what to leave alone) and an `INDEX.md` (what every file is). Read both before touching the folder.
3. The pages themselves.
4. The log and older material.
5. Raw sources, last.

## One receipt
The method ran against a working folder of about 120,000 files, roughly 95% of them dependency files from code projects, with about 900 notes of real content. No vector index existed. The agent never opened the dependency files, because no instruction pointed there. That is one observation on one folder, not a benchmark.

## What it does not do
- It finds what its catalog describes. "What did I say about this, months ago" fails if no row mentions it.
- It is discipline, not infrastructure: someone has to keep the catalog current.
- Boundaries are conventions. For a hard wall, use separate folders with filesystem permissions.

The full paper, with the failure modes and the maintenance checks, is in `docs/` of the paid kits.
