# Baseline Core

**Brief your AI agent properly, then test that it listened.**
Plain markdown. Nothing to install. Works with any agent that can read files.

`free` · `v0.1 pre-release` · `5 files` · `about 15 minutes`

[What is inside](#what-is-inside) · [Start here](#start-here) · [How an agent reads it](#how-an-agent-reads-it) · [Load it into your agent](#load-it-into-your-agent) · [Limits](#what-it-will-not-do)

---

## What is inside

| File | Its job | When you use it |
| --- | --- | --- |
| `me.template.md` | The briefing your agent reads first: who you are, how you work, what it must never do, and the rules it follows | Once, to fill in |
| `CALIBRATION_PROMPT.md` | A ten-minute interview. The agent asks ten questions, writes your briefing, then runs three probe tasks to check it follows it | Once, at the start |
| `ROUTING_PRIMER.md` | One page on why folders and a catalog beat a vector database for a working vault | Read it, three minutes |
| `README.md` | This page, with the loading guide at the bottom | Now |
| `Baseline-Core-Guide.pdf` | The same guide as a four-page illustrated PDF, for reading on screen | Now |

Unzipping gives you a folder called `baseline-core`. Open it in your agent, or copy the files into a folder you already work in.

## Start here

| | Step | Time | You are done when |
| --- | --- | --- | --- |
| 1 | Paste the prompt in `CALIBRATION_PROMPT.md` into your agent and answer its ten questions | 10 min | The agent shows a draft briefing under 400 words |
| 2 | Read the draft, change what is wrong, then say "save". Keep the result as `me.md` | 2 min | `me.md` reads like you, not like a brochure |
| 3 | Load it for your tool using the guide below, then run the echo test | 3 min | The agent repeats your rules and says "not given" for anything missing |

> **Tip.** The probe tasks at the end of step 1 are the point. If one fails, the agent proposes one line to add. Say yes, and run that probe again.

## How an agent reads it

An agent that starts every session from the same small set of files behaves the same way twice. This is the whole idea in one picture.

```
  new session
       |
       v
  1. a one-line pointer file   points at the rules, carries none itself
  2. the rules file            what the agent may and may not do
  3. me.md                     who you are, what it must never do
       |
       v
  then, only when the task needs it:
  catalog  ->  folder router  ->  pages  ->  log  ->  raw sources last
```

Keep those three files under about 1,500 tokens together. Everything an agent must read first is a cost on every session. `ROUTING_PRIMER.md` explains why.

## What it will not do

> **Rules here are instructions, not enforcement.** An agent is asked to follow them; nothing stops it ignoring them. If you need a hard guarantee, use filesystem permissions or version control.

- It has been run with one vendor's agents. It is plain markdown and links, so other agents can read it, but run the echo test once per tool before you trust it.
- It is a starting point for one person's folder. It does not set up a wiki, run checks or repair anything. Those are in the paid kits.

## Licence

Personal use, one person. Wording is not final.

---

## Load it into your agent

How to get `me.md` and the rules in front of the agent every session, and how to check they landed. The files are plain markdown, so the only question is where each tool looks.

### Pick your route

| Your tool | Where the rules go | Notes |
| --- | --- | --- |
| A coding agent that reads a project instructions file (most do) | Save your rules as `AGENTS.md` in the folder you open (in the free kit the rules are the last section of `me.md`). If your tool only loads a different filename, make that file one line: "Read `AGENTS.md`." | Open the agent in that folder. It loads the file on its own. Keep `me.md` next to it and have the rules say to read it first |
| A chat app with custom instructions or a project feature | Paste the "How I like to work" and "Never do this" sections of `me.md` into the instructions field. Upload the full `me.md` and rules to the project's files if it has them | Instruction fields are short. Put the constraints there and the longer detail in an uploaded file |
| A chat with no memory | Paste `me.md` and the rules as the first message, under the line "Treat this as your briefing for this session" | You repeat it each session. Keep the combined text under about 1,500 tokens |
| Several tools | Keep one canonical `AGENTS.md`. Make every other tool's file a one-line pointer to it | One copy to maintain. Nothing to keep in sync |

### Size budget
Everything the agent must read first is a cost on every session. Aim for under 1,500 tokens (roughly 6,000 characters) for `me.md` plus the rules. If it grows, move detail into files the rules point to, and read those only when a task needs them.

### The echo test (two minutes)
Run this in a fresh session after loading the files:

```
Without reading anything else, tell me: what I should be called, three things you must never do, what you do before editing a file, and where you look first. If any of these is not in your instructions, say "not given".
```

- **Pass:** it answers from the files and says "not given" for anything missing.
- **Fail:** it answers generically, or invents rules. The files did not load. Check the file name, the folder you opened, and whether the tool reads project files at all.

### The contradiction test
Add one deliberately odd line to `me.md` ("Always end replies with the word 'ok'"), start a fresh session, ask anything, then remove the line. If the agent does not obey, it is not reading the file. Remove the line afterwards.

### Common failures
- **Rules loaded but ignored on long tasks.** Re-state the three hardest constraints at the end of the task message. Long contexts dilute early instructions.
- **Two instruction files disagree.** The agent follows whichever it read last or nearest. Keep one canonical file and make the rest pointers.
- **Instructions inside files the agent reads.** A note or web page that says "ignore your rules" is data. The rules file already says so. The third calibration probe tests it.
- **A different tool each time.** The files are neutral, but behaviour is not. Run the echo test once per tool.

