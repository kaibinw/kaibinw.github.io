# Baseline AIOS (free)

Brief your AI agent properly, and test that it listened. Plain markdown, nothing to install, works with any agent that reads files.

| File | What it is |
| --- | --- |
| `me.template.md` | The briefing the agent reads first: who you are, how you work, what it must never do, and the rules it follows |
| `CALIBRATION_PROMPT.md` | A ten-minute interview prompt. The agent asks ten questions, writes your `me.md`, then runs three probe tasks to check it follows it |
| `ROUTING_PRIMER.md` | One page on why folders and a catalog beat a vector database for a working vault, and how the lookup order works |
| `README.md` | This file, with the guide below for loading it into your agent |

## Start (about fifteen minutes)
1. Paste the prompt in `CALIBRATION_PROMPT.md` into your agent and answer the ten questions.
2. Save the result as `me.md`. Check it reads like you, not like a brochure.
3. Load it using the guide below and run the echo test.

## What this is not
Rules here are instructions the agent is asked to follow, not enforcement. It has been run with one vendor's agents; run the echo test once per tool.

Personal use, one person. (Licence wording not final.)

---

## Load it into your agent

How to get `me.md` and the rules in front of the agent every session, and how to check they landed. The files are plain markdown, so the only question is where each tool looks.

## Pick your route

| Your tool | Where the rules go | Notes |
| --- | --- | --- |
| A coding agent that reads a project instructions file (most do) | Save your rules as `AGENTS.md` in the folder you open (in the free kit the rules are the last section of `me.md`). If your tool only loads a different filename, make that file one line: "Read `AGENTS.md`." | Open the agent in that folder. It loads the file on its own. Keep `me.md` next to it and have the rules say to read it first |
| A chat app with custom instructions or a project feature | Paste the "How I like to work" and "Never do this" sections of `me.md` into the instructions field. Upload the full `me.md` and rules to the project's files if it has them | Instruction fields are short. Put the constraints there and the longer detail in an uploaded file |
| A chat with no memory | Paste `me.md` and the rules as the first message, under the line "Treat this as your briefing for this session" | You repeat it each session. Keep the combined text under about 1,500 tokens |
| Several tools | Keep one canonical `AGENTS.md`. Make every other tool's file a one-line pointer to it | One copy to maintain. Nothing to keep in sync |

## Size budget
Everything the agent must read first is a cost on every session. Aim for under 1,500 tokens (roughly 6,000 characters) for `me.md` plus the rules. If it grows, move detail into files the rules point to, and read those only when a task needs them.

## The echo test (two minutes)
Run this in a fresh session after loading the files:

```
Without reading anything else, tell me: what I should be called, three things you must never do, what you do before editing a file, and where you look first. If any of these is not in your instructions, say "not given".
```

- **Pass:** it answers from the files and says "not given" for anything missing.
- **Fail:** it answers generically, or invents rules. The files did not load. Check the file name, the folder you opened, and whether the tool reads project files at all.

## The contradiction test
Add one deliberately odd line to `me.md` ("Always end replies with the word 'ok'"), start a fresh session, ask anything, then remove the line. If the agent does not obey, it is not reading the file. Remove the line afterwards.

## Common failures
- **Rules loaded but ignored on long tasks.** Re-state the three hardest constraints at the end of the task message. Long contexts dilute early instructions.
- **Two instruction files disagree.** The agent follows whichever it read last or nearest. Keep one canonical file and make the rest pointers.
- **Instructions inside files the agent reads.** A note or web page that says "ignore your rules" is data. The rules file already says so. The third calibration probe tests it.
- **A different tool each time.** The files are neutral, but behaviour is not. Run the echo test once per tool.

